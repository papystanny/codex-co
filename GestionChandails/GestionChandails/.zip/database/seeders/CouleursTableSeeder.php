<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class CouleursTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        DB::table('couleurs')->insert([
            [
                'nom'=>'Noir'
            ],
            [
                'nom'=>'Blanc'
            ],
            [
                'nom'=>'Indigo'
            ],
            [
                'nom'=>'Bleu'
            ],
            [
                'nom'=>'Fluo'
            ],
            [
                'nom'=>'Vert'
            ],
            [
                'nom'=>'Orange'
            ],
            [
                'nom'=>'Onyx'
            ],
            [
                'nom'=>'Gris'
            ],
            [
                'nom'=>'Marron'
            ],
            [
                'nom'=>'Beige'
            ],
            [
                'nom'=>'Bougorgne'
            ],
            [
                'nom'=>'Bleu Turquoise'
            ]

         ]);
    }
}
