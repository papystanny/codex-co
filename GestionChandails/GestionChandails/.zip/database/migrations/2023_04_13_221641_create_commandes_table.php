<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('commandes', function (Blueprint $table) {
            $table->primary(['usager_id', 'article_id']);
            $table->foreignId('usager_id')->constrained()->onDelete('cascade');;
            $table->foreignId('article_id')->constrained()->onDelete('cascade');;
            $table->date('date',100);
            $table->string('staut',100);
            $table->integer('quantite');
            $table->string('etat',100);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        
        Schema::dropIfExists('commandes');
    }
};
